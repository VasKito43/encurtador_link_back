CREATE TABLE "usuario" (
	"id" uuid PRIMARY KEY NOT NULL,
	"nome" text NOT NULL,
	"senha" text NOT NULL
);
